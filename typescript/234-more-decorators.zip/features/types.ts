const today = new Date();
today.getMonth();

const person = {
  age: 20,
};

class Color {}
const red = new Color();
